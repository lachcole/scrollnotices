<!DOCTYPE html>
<head>
<style>
*{
animation: anims 2s infinite alternate;
}
@keyframes anims {
from{background-color: <?php echo $_GET["colour"] ?: "black"; ?>;}
to{background-color: <?php echo $_GET["colourto"] ?: "black"; ?>;}
}
</style>
</head>