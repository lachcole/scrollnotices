<!DOCTYPE html>
<head>
<style>
body {
    background-color: <?php echo $_GET["colour"] ?: "black"; ?>;
}
</style>
</head>	