$(function() {
	var args = getUrlParams();
	if (args.footer != null) $('footer').show();
	// Do first fetch of notices
	updateNotices();
	// Routinely update date and time
	setInterval(updateDate, 1000);
	// Do first update of date and time
	updateDate();
});


function updateNotices() {
	// Get HTML from iLearn for daily notices
	var attempts = 0;
	function getNotices() {
		attempts++;
		function attemptGet() {
			var address = 'notices';
			$.get(address, getNoticesSuccess).fail(getNotices);
		}
		if (attempts > 1) setTimeout(attemptGet, 5000);
		else attemptGet();
	}
	getNotices();	

	function getNoticesSuccess(data) {
		var html = $(data);
		// Clear and reset notices
		/*$('.eventlist').empty().animate({'margin-top': 0}, 200, 'linear', function() {
			scrollNotices();
		});*/
		$('.eventlist').empty();
		scrollNotices();
		// Move notices from downloaded HTML to DOM
		html.find('.eventlist .event').appendTo($('.eventlist'));
		// Add yellow line under title
		$('h3.name').append($('<hr noshade>'));
		// Resize responsive (full-width) images to fit
		var img = $('img.img-responsive');
		img.width('100%');
		img.height('auto');
	}

	var attempts2 = 0;
	function getSpreadsheet() {
		attempts2++;
		function attemptGet() {
			var address = 'spreadsheet';
			$.get(address, getSpreadsheetSuccess).fail(getSpreadsheet);
		}
		if (attempts2 > 1) setTimeout(attemptGet, 5000);
		else attemptGet();
	}
	getSpreadsheet();

	// Get CSV from Google Docs for daily information

	function getSpreadsheetSuccess(rawData) {
		var data = $.csv.toObjects(rawData);

		// Find current day of year
		// @src http://www.devcurry.com/2011/08/javascript-find-day-of-year.html
		var timestmp = new Date().setFullYear(new Date().getFullYear(), 0, 1);
		var yearFirstDay = Math.floor(timestmp / 86400000);
		var today = Math.ceil((new Date().getTime()) / 86400000);
		var numericDayOfYear = today - yearFirstDay;

		// Get data for today, accounting for zero-indexing
		var today = data[numericDayOfYear - 1];

		// Update displayed date
		$('span#date').text(today.dayOfYear);
		$('div#date').show();

		// Update numeric day if it exists
		if (today.numericDay) {
			$('span#dayNum').text(today.numericDay);
			$('span#day').show();
		} else {
			$('span#day').hide();
		}

		// Update message if it exists
		if (today.message) {
			var $message = $('div#message');
			$message.html(today.message.replace(/\|/g, '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'));
			// Scroll infinitely if message is wider than screen
			if ($message.width() > $('#messagecontainer').width()) {
				$message.css('animation-duration', ($message.width() * 40) + 'ms');
				$message.addClass('scrolling');
			} else $message.removeClass('scrolling');
		}
		
	}
}

var lastChecked = (new Date()).getTime();

function scrollNotices() {
	setTimeout(function() {
		var now = (new Date()).getTime();
		if (now - lastChecked > 10 * 60 * 1000) {
			lastChecked = now;
			updateNotices();
		} else {
			var h = $('html').height();
			h = h - $(window).height() / 3 + ($('footer').is(':visible') ? $('footer').height() : 0);

			$('.eventlist').animate({'margin-top': -h}, h * 100, 'linear', function() {
				setTimeout(function() {
					$('.eventlist').animate({'margin-top': 0}, 200, 'linear', function() {
						scrollNotices();
					});
				}, 3000);
				$('.eventlist').stop();
			});
		}
	}, 500);
}

function stopScrollingNotices() {
	$('.eventlist').stop();
}

function updateDate() {
	var time = new Date().toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1");
	$('#time span').text(time);
	//var date = new Date().toDateString();
}

// @src(modified) http://stackoverflow.com/questions/520611/how-can-i-match-multiple-occurrences-with-a-regex-in-javascript-similar-to-phps
function getUrlParams(url) {
	var re = /(?:\#|&(?:amp;)?)([^=&]+)(?:=?([^&]*))/g,
		match, params = {},
		decode = function (s) {
			return decodeURIComponent(s.replace(/\+/g, ' '));
		};

	if (typeof url == 'undefined') url = document.location.href;

	while (match = re.exec(url)) {
		params[decode(match[1])] = decode(match[2]);
	}
	return params;
}					