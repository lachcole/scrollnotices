<?php

$str = file_get_contents('https://docs.google.com/spreadsheets/d/1t-GE3hofrQiC-FMHRIv7s2eMfh09PSM4D0kfoLJ_lbs/export?format=csv&gid=1553957910');
echo $str;

?>