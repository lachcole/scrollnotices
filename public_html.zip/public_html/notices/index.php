<?php

$str = file_get_contents('https://ilearn.stpauls.school.nz/calendar/view.php?view=upcoming&course=1');
echo $str;

?>